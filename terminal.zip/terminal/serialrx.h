#ifndef SERIALRX
#define SERIALRX
#include <QThread>
#include <QMutex>
#include <QWaitCondition>
#include <QFile>
#include <QTextStream>
#include <QDateTime>

#include <QtSerialPort/QSerialPort>

#include <QTime>
//! [0]
class serialRxThread : public QThread
{
    Q_OBJECT

public:
    serialRxThread(QObject *parent = 0);
    ~serialRxThread();

    bool startSlave(QString name, qint32 baudRate,QSerialPort::DataBits dataBits, QSerialPort::Parity parity,
                    QSerialPort::StopBits stopBits, QSerialPort::FlowControl flowControl,
                    QString response);
    void stopSlave();
    void run();

    void setSaveFile(QFile *SaveDataFile, const QString fileName);

signals:
    void request(const QString &s);
    void error(const QString &s);
    void timeout(const QString &s);
    void saveFile();

private:

    QString portName; //select port name
    qint32 baudRate;
    QSerialPort::DataBits dataBits;
    QSerialPort::Parity parity;
    QSerialPort::StopBits stopBits;
    QSerialPort::FlowControl flowControl;

    QString response;
    bool currentPortNameChanged;
    QString currentPortName;
    int waitTimeout;
    QMutex mutex;
    bool quit;
    QString SaveFileName;
    QFile *SaveDataFile;


    void saveData2File(QString data);
    void getTimeString(QString &outStr);
};
//! [0]
#endif // SERIALRX

