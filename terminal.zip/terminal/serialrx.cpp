/****************************************************************************
**
** Copyright (C) 2012 Denis Shienkov <denis.shienkov@gmail.com>
** Contact: http://www.qt.io/licensing/
**
** This file is part of the QtSerialPort module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL21$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see http://www.qt.io/terms-conditions. For further
** information use the contact form at http://www.qt.io/contact-us.
**
** GNU Lesser General Public License Usage
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 2.1 or version 3 as published by the Free
** Software Foundation and appearing in the file LICENSE.LGPLv21 and
** LICENSE.LGPLv3 included in the packaging of this file. Please review the
** following information to ensure the GNU Lesser General Public License
** requirements will be met: https://www.gnu.org/licenses/lgpl.html and
** http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** As a special exception, The Qt Company gives you certain additional
** rights. These rights are described in The Qt Company LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "serialrx.h"


QT_USE_NAMESPACE

serialRxThread::serialRxThread(QObject *parent)
    : QThread(parent), waitTimeout(0), quit(false)
{
    QMutexLocker locker(&mutex);
    SaveDataFile = 0;
    currentPortNameChanged = false;
}
//! [0]
serialRxThread::~serialRxThread()
{
    mutex.lock();
    quit = true;
    mutex.unlock();
    wait();
}

void serialRxThread::stopSlave()
{
    mutex.lock();
    quit = true;
    mutex.unlock();
    wait();
}
//! [0]

//! [1] //! [2]
bool serialRxThread::startSlave(QString name, qint32 baudRate,QSerialPort::DataBits dataBits, QSerialPort::Parity parity,
                QSerialPort::StopBits stopBits, QSerialPort::FlowControl flowControl,
                QString response)
{
//! [1]
    this->portName = name;
    this->waitTimeout = 1000;
    this->response = response;

    this->currentPortName = name;
    this->baudRate = baudRate;
    this->dataBits = dataBits;
    this->parity = parity;
    this->stopBits = stopBits;
    this->flowControl = flowControl;

    this->currentPortNameChanged = true;

    if (!isRunning())
        start();
    quit = false;
    return true;
}
//! [2] //! [3]

//! [4]
void serialRxThread::run()
{
    mutex.lock();
//! [4] //! [5]
    int currentWaitTimeout = waitTimeout;
    QString currentRespone = response;
    mutex.unlock();
//! [5] //! [6]
    long SaveLen = 0;
    long totallen = 0;
    int  totalSaveFile = 0;
    QSerialPort serial;
    currentPortNameChanged = true; //conect at first
    QByteArray requestData="";
    while (!quit) {
//![6] //! [7]
        if (currentPortNameChanged) {
            emit this->request(tr("Try Open %1\r\n")
                               .arg(portName));
            serial.close();
            serial.setPortName(currentPortName);
            serial.setBaudRate(baudRate);
            serial.setDataBits(dataBits);
            serial.setParity(parity);
            serial.setStopBits(stopBits);
            serial.setFlowControl(flowControl);

            if (!serial.open(QIODevice::ReadWrite)) {
                emit this->request(tr("Can't open %1, error code %2\r\n")
                                   .arg(portName).arg(serial.error()));
                this->stopSlave();
            }else{                
                currentPortNameChanged = false;
                serial.clear();
                emit this->request(tr("Open %1 Success.\r\nWait for incoming data.\r\n")
                                   .arg(portName));
            }
        }
        if (!serial.isOpen()){
            msleep(500);
            continue;
        }

        if (serial.waitForReadyRead(currentWaitTimeout)) {
            requestData.push_back(serial.readAll()); // request data
            if(!requestData.endsWith('\n') || requestData.length()<3)
                continue;

            // get local time
            QString timeStamp;
            getTimeString(timeStamp);
            QString request(requestData);
            requestData = ""; //clear requestData buffer
            request.push_front(timeStamp);

            int iNextEnd = request.indexOf('\n',timeStamp.length()+4)+1;
            int len = request.length();
            if(iNextEnd<len){
                while(1){
                    request.insert(iNextEnd,timeStamp);
                    iNextEnd += timeStamp.length();
                    len = request.length();

                    iNextEnd = request.indexOf('\n',iNextEnd)+1;

                    if(iNextEnd>=len || iNextEnd<0)
                        break;
                }
            }

            mutex.lock();
            if(SaveDataFile && request.length()>0){
                if(SaveDataFile->isOpen()){
                    if(++totallen>15000){
                        totallen = 0;
                        SaveLen = 0;
                        SaveDataFile->flush();
                        SaveDataFile->close();
                        delete SaveDataFile;
                        SaveDataFile = 0;
                        QString fNum = QString::number(++totalSaveFile);

                        QString tempFileName = SaveFileName;
                        tempFileName.insert(SaveFileName.length()-4,"-" );
                        tempFileName.insert(SaveFileName.length()-3,fNum);
                        SaveDataFile = new QFile(tempFileName);

                        SaveDataFile->open(QFile::WriteOnly |QFile::Truncate);
                    }

                    QTextStream output(SaveDataFile);

                    output << request;

                    if(SaveLen++>1023){
                        SaveLen = 0;
                        SaveDataFile->flush();
                    }                    
                }
            }
            mutex.unlock();

            emit this->request(request);
//! [8] //! [9]
        } else {
            emit timeout(tr("Wait read request timeout %1")
                         .arg(QTime::currentTime().toString()));
        }
//! [9]  //! [13]
        mutex.lock();
        if (currentPortName != portName) {
            currentPortName = portName;
            currentPortNameChanged = true;
        } else {
            currentPortNameChanged = false;
        }
        currentWaitTimeout = waitTimeout;
        currentRespone = response;
        mutex.unlock();
    }
    serial.close();
//! [13]
}

void serialRxThread::setSaveFile(QFile *f, QString fileName)
{
    mutex.lock();
    if(f==0){
        if(SaveDataFile){
            SaveDataFile->close();
            delete SaveDataFile;
        }
    }
    SaveDataFile = f;
    SaveFileName = fileName;
    mutex.unlock();
}

void serialRxThread::getTimeString(QString &outStr)
{

    QDateTime curDateTime = QDateTime::currentDateTimeUtc();
    QTime curTime =  QTime::currentTime();

    outStr.push_back(curDateTime.toString());
    outStr.push_back(',');
    uint msecs = curTime.msecsSinceStartOfDay();
    outStr.push_back(QString::number(msecs));
    outStr.push_back(',');
}

